import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddFoodComponent } from './add-food/add-food.component';
import { DeletefoodComponent } from './deletefood/deletefood.component';
import { SearchfoodComponent } from './searchfood/searchfood.component';
import { UpdatfoodComponent } from './updatfood/updatfood.component';
import { FoodlistComponent } from './foodlist/foodlist.component';
import { KitchenService } from './kitchen.service';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    AppComponent,
    AddFoodComponent,
    DeletefoodComponent,
    SearchfoodComponent,
    UpdatfoodComponent,
    FoodlistComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
  ],
  providers: [KitchenService],
  bootstrap: [AppComponent]
})
export class AppModule { }
