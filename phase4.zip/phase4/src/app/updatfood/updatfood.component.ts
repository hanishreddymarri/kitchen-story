import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updatfood',
  templateUrl: './updatfood.component.html',
  styleUrls: ['./updatfood.component.css']
})
export class UpdatfoodComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
