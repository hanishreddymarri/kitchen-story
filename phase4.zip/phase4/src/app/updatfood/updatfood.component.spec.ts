import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatfoodComponent } from './updatfood.component';

describe('UpdatfoodComponent', () => {
  let component: UpdatfoodComponent;
  let fixture: ComponentFixture<UpdatfoodComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatfoodComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatfoodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
