export class Food {
      id:number;
	  food:string;
	  cost:number;
	  category:string;
}
