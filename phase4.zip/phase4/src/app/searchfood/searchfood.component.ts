import { Component, OnInit } from '@angular/core';
import { Food } from '../food';
import { KitchenService } from '../kitchen.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-searchfood',
  templateUrl: './searchfood.component.html',
  styleUrls: ['./searchfood.component.css']
})
export class SearchfoodComponent implements OnInit {
  private fooditems:Food
  constructor(private kitchenservice:KitchenService,private router:Router) { 
  }
public getAllFoodItemsByFood(food:string):void
{
this.kitchenservice.getAllFoodItemsByFood('food').subscribe(food=>{ 
this.fooditems=food
  this.router.navigate(['/foodlist'])
})
}
public getAllFoodItemsByCategory(category:string):void
{
  this.kitchenservice.getAllFoodItemsByCategory("category").subscribe(food=>{
    this.fooditems=food;
    this.router.navigate(['/foodlist'])
  })
}
  ngOnInit() {
   /* this.kitchenservice.getAllFoodItemsByFood("food").subscribe(food=>{
   this.food=food
      this.router.navigate(['/foodlist']); 
    }
    )
    this.kitchenservice.getAllFoodItemsByCategory('category').subscribe(res=>{
      this.food=res
      this.router.navigate(['/foodlist']); 
    })*/


  }

}
