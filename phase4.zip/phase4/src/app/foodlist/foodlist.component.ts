import { Component, OnInit } from '@angular/core';
import { KitchenService } from '../kitchen.service';
import { Food } from '../food';

@Component({
  selector: 'app-foodlist',
  templateUrl: './foodlist.component.html',
  styleUrls: ['./foodlist.component.css']
})
export class FoodlistComponent implements OnInit {
  private foodlist:Food[];
  constructor(private kitchenservice:KitchenService) { }

  ngOnInit() {
    this.kitchenservice.getAllFoodItems().subscribe(res=>
      {this.foodlist=res})
  }

}
