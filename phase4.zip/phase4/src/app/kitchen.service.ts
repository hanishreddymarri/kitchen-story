import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Food } from './food';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class KitchenService {
private  url:string
  constructor(private http:HttpClient) { 
    this.url="http://localhost:8080/foodItems";
  }

public addFoodItems(food:Food):Observable<Food>
{
return this.http.post<Food>(this.url,food);
}
public getAllFoodItems():Observable<Food[]>
{
return this.http.get<Food[]>(this.url);
}
public getAllFoodItemsByCategory(category:string):Observable<Food>
{
 return this.http.get<Food>(`${this.url+"/category"}/${category}`);

}
public deleteFoodItemsById(id:number):Observable<Food>
{
  return this.http.delete<Food>(`${this.url}/${id}`);
}
public getAllFoodItemsByFood(food:string):Observable<Food>
{
  return this.http.get<Food>(`${this.url+"/food"}/${food}`);
}
public updateFoodItems(food:Food):Observable<Food>
{
return this.http.put<Food>(this.url,Food);
}


}
