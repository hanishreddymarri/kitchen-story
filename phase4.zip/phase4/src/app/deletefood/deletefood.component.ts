import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { parse } from 'querystring';
import { Food } from '../food';
import { KitchenService } from '../kitchen.service';

@Component({
  selector: 'app-deletefood',
  templateUrl: './deletefood.component.html',
  styleUrls: ['./deletefood.component.css']
})
export class DeletefoodComponent implements OnInit {
private fooditem:Food
  constructor(private kitchservice:KitchenService,private routing:Router) { }
  public deleteFoodItemsById():void{
    this.kitchservice.deleteFoodItemsById(this.fooditem.id).subscribe(res=>{
      this.fooditem=res;
      this.routing.navigate(['/foodlist'])
    })

  }
  ngOnInit() {
  }

}
