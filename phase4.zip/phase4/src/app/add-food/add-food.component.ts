import { Component, OnInit } from '@angular/core';
import { Food } from '../food';
import { KitchenService } from '../kitchen.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-food',
  templateUrl: './add-food.component.html',
  styleUrls: ['./add-food.component.css']
})
export class AddFoodComponent implements OnInit {
  private foodlist:Food;
  constructor(private kitchenService:KitchenService,private  router:Router) { 
    this.foodlist=new Food();

  }
  public addFoodItems():void{
    this.kitchenService.addFoodItems(this.foodlist).subscribe(res=>{
      this.foodlist=new Food();
      this.router.navigate(['/foodlist'])
    })
  }
  ngOnInit() {
  }

}
