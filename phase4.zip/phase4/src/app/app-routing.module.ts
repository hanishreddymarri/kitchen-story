import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddFoodComponent } from './add-food/add-food.component';
import { DeletefoodComponent } from './deletefood/deletefood.component';
import { FoodlistComponent } from './foodlist/foodlist.component';
import { SearchfoodComponent } from './searchfood/searchfood.component';
import { UpdatfoodComponent } from './updatfood/updatfood.component';


const routes: Routes = [
  {path:'addfooditems',component:AddFoodComponent},
  {path:'deletefooditemsById',component:DeletefoodComponent},
  {path:'foodlist',component:FoodlistComponent},
  {path:'searchfooditemsByFood',component:SearchfoodComponent},
  {path:'searchfooditemsByCatagory',component:SearchfoodComponent},
  {path:'updatefooditems',component:UpdatfoodComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
